<template>
  <div class="flex items-start p-1 space-x-5 w-full">
    <div class="w-44 h-18 overflow-hidden">
      <img
        src="https://mksdmcdn-9b59.kxcdn.com/voice/wp-content/uploads/2014/11/voice_29-380x260.jpg.webp"
        class="w-full h-full transform transition duration-500 hover:scale-110 cursor-pointer"
        alt=""
      />
    </div>
    <div class="pt-1">
      <h2
        class="text-sm font-poppin text-white hover:text-primary font-semibold transform transition duration-500 cursor-pointer"
      >
        For Jazz Appreciation Month: Jazz Artists Who...
      </h2>
      <p class="text-gray-900 text-xs pt-1">8,383 Views</p>
    </div>
  </div>
</template>
